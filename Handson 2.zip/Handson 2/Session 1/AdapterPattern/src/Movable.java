
public interface Movable {
	
	double getSpeed();
	
	double getPrice();
}
