
public class DB {
	
private static DB instance=new DB();
	
	private DB() {
		
	}
	
	public static DB getInstance()
	{
		return instance;
	}
	

}
