public abstract class AbstractFactory {
	public abstract Car buildCar(CarType model, Location location);
}