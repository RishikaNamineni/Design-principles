
public abstract class INotificationObserver {
	private String name;

	public abstract void OnServerDown();
	
	

	public INotificationObserver(String name) {
		super();
		this.name = name;
	}

	

	public INotificationObserver() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}