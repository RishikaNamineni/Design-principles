public class Main {

	public static void main(String[] args) {

		INotificationObserver Ojohn = new JohnObserver();
		INotificationObserver Osteve = new SteveObserver();
		
		INotificationService notificationService = new NotificationService();
		notificationService.AddSubscriber(Osteve);
		notificationService.AddSubscriber(Ojohn);
		notificationService.NotifySubscriber();
		notificationService.RemoveSubscriber(Ojohn);
	}

}