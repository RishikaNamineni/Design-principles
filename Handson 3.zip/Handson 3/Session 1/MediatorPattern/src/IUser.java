public interface IUser {

	public void ReceiveMessage(String message);
	public void SendMessage();
}