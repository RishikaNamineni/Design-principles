package sampleApp;

public interface IRepair {

	void processRepair(String repair);
}
