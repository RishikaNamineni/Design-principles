
public class Vivo7 implements Iphone {

	@Override
	public String getPhonePart1() {
		return "Battery";
	}

	@Override
	public double getPart1Cost() {
		return 900;
	}

}