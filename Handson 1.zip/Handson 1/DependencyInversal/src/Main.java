
public class Main {

	public static void main(String[] args) {

		Iphone phone1 = new RealmeX3();
		Iphone phone2 = new Vivo7();
		
		ProcessRepair repair = new ProcessRepair();
		repair.RepairSteps(phone1);
		repair.RepairSteps(phone2);
	}

}