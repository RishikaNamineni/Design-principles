package sampleApp;

public interface IOrder {
	void processOrder(String modelName);
}

