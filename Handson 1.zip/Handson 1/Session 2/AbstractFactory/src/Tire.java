public abstract class Tire {

}