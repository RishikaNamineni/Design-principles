
public class Main {

	public static void main(String[] args) {

		INotificationObserver observer0 = new AdminObserver("Teju");
		INotificationObserver observer1 = new AdminObserver("Maggie");
		INotificationObserver observer2 = new AdminObserver("Yashu"); 
		
		INotificationService service = new NotificationService();
		
		service.AddSubscriber(observer0);
		service.AddSubscriber(observer1);
		service.AddSubscriber(observer2);
		Event event0 = new Event("Tej_Organisations", 900);
		Event event1 = new Event("Maggie studio", 600);
		Event event2 = new Event("yash All in one", 300);
		
		service.NotifySubscriber(event0);
		
		service.RemoveSubscriber(observer1);
		
		service.NotifySubscriber(event1);
		
		service.NotifySubscriber(event2);
	}

}