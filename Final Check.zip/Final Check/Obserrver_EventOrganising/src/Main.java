public class Main {

	public static void main(String[] args) {

		INotificationObserver admin1 = new AdminObserver("Teju");
		INotificationObserver admin2 = new AdminObserver("Maggie");
		INotificationObserver admin3 = new AdminObserver("Yashu"); 
		
		INotificationService service = new NotificationService();
		
		service.AddSubscriber(admin1);
		service.AddSubscriber(admin2);
		service.AddSubscriber(admin3);
		Event event1 = new Event("Tej_Organisations", 900);
		Event event2 = new Event("Maggie studio", 600);
		Event event3 = new Event("yash All in one", 300);
		
		service.NotifySubscriber(event1);
		
		service.RemoveSubscriber(admin2);
		
		service.NotifySubscriber(event2);
		
		service.NotifySubscriber(event3);
	}

}