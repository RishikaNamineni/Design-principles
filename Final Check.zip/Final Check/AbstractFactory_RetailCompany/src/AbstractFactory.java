
public abstract class AbstractFactory {
	public abstract Order createOrder(String channel, String productType);
}